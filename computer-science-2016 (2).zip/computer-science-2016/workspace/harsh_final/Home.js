$(document).ready(function() {
    $('.carousel').carousel();
  });

  $('.carousel.carousel-slider').carousel({
    full_width: true
  });
  // Next slide
  $('.carousel').carousel('next', 3); // Move next n times.


      
        